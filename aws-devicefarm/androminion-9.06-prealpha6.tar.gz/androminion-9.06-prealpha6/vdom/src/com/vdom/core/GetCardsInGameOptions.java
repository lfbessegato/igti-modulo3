package com.vdom.core;

public enum GetCardsInGameOptions {
    TopOfPiles,
    Buyables,
    Templates,
    Placeholders,
    All
}

