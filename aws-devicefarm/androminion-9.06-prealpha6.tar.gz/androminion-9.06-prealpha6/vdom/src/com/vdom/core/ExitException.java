package com.vdom.core;

@SuppressWarnings("serial")
public class ExitException extends RuntimeException {

}
