package com.vdom.api;


public interface GameEventListener {
    public void gameEvent(GameEvent event);
}
