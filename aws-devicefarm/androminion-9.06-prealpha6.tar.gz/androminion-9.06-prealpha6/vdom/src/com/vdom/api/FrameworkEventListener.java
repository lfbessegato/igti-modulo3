package com.vdom.api;

public interface FrameworkEventListener {
    public void frameworkEvent(FrameworkEvent frameworkEvent);
}
