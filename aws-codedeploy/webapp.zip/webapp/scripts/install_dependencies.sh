#!/bin/bash
# apt install apache2 -y
yum install httpd -y

