#!/bin/bash
# service apache2 stop
service httpd stop

